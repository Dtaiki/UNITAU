public class Node {
    private int x;
    private Node prox;

    public Node(int x){
        this.x = x;
        this.prox = null;
    }
    
    public void add(int x){
        if(prox!=null){
            prox.add(x);
        }
        else{
            prox = new Node(x);
        }
    }
    
    public int soma(){
        int s = 0;
        if(prox!=null){
            s = prox.soma();
        }
        return this.x + s;
    }
    
    public void show(){
        System.out.println(x);
        if(prox!=null){
            prox.show();
        }
        
    }
    
    public int maior(){
        int m = 0;
        if(prox!=null){
            m = prox.maior();
        }
        if(this.x>m){
            return x;
        }
        else{
            return m;
        }
    }
}
