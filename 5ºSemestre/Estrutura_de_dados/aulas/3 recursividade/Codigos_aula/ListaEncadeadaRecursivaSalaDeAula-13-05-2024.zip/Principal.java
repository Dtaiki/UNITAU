public class Principal{
    public static void main(String[] args) {
        Lista l = new Lista();
        l.add(10);
        l.add(20);
        l.add(90);
        l.add(40);

        System.out.println(l.soma());
        System.out.println(l.maior());
        
        l.show();
        
        
    }

}
