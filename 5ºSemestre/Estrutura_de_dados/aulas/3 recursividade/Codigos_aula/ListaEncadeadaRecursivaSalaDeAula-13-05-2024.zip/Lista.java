public class Lista {
    private Node inicio;

    public Lista(){
        inicio = null;
    }

    public void add(int x){
        if(inicio!=null){
            inicio.add(x);
        }
        else{
            inicio = new Node(x);
        }
    }

    public int soma(){
        if(inicio!=null){
            return inicio.soma();
        }
        else{
            return 0;
        }
    }
    
    public void show(){
       if(inicio!=null){
            inicio.show();
        } 
    }

    public int maior(){
        if(inicio!=null){
            return inicio.maior();
        }
        else{
            return 0;
        }
    }
    
}
