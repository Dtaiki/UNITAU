public class Principal
{
    public static void main(String args[]){
        ListaR l = new ListaR();
        
        l.add(10);  //adiciona valores à lista
        l.add(20);
        l.add(30);
        l.add(10);  //adiciona valores à lista
        l.add(20);
        l.add(80);
        l.add(10);  //adiciona valores à lista
        l.add(20);
        l.add(30);
        //l.show();   // imprime na tela os valores armazenados na lista
        //System.out.println(l.size());
        //System.out.println(l.soma());
        //System.out.println(l.maior());
        //System.out.println(l.qtdNosComValor(30));
        l.showPosPares();
    }
}
