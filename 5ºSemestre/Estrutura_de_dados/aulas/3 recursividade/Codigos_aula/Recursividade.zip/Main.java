public class Main{
    public static void Hanoi(int N, char O, char D, char A){
        if(N>1){
            Hanoi(N-1, O, A, D);
            System.out.println("Mover anel "+N+" da Torre "+O+" para a Torre "+D);
            Hanoi(N-1, A, D, O);
        }
        else{
            System.out.println("Mover anel 1 da Torre "+O+" para a Torre "+D);
        }
    }
    
    public static void main(String args[]){
        Hanoi(3, 'A', 'C', 'B');
    }
}
