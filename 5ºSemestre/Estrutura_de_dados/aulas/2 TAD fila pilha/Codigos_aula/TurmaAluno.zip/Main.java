public class Main {
  public static void main(String[] args) {
    double[] notas = {10, 9, 8, 7};
    double[] notas2 = new double[4];
    double[] notas3 = notas;

    notas2[0] = 10.;
    notas2[1] = 7.;
    notas2[2] = 10.;
    notas2[3] = 7.;

    notas3[0] = 3.;
    
    System.out.println(notas);
    System.out.println(notas2);
    System.out.println(notas.length);
    System.out.println(notas[0]);
    System.out.println(notas[3]);

    Turma t1 = new Turma("5º Ano EC", 10);

    // criar entrada de dados de um aluno

    
    
    t1.adicionarAluno(new Aluno("João", 1, "Informática", notas);
    
  }

}