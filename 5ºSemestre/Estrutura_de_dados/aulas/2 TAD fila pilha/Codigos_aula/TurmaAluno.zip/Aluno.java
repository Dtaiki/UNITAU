public class Aluno{
  String nome;
  int matricula;
  String curso;
  double notas[];

  public Aluno(String nome, int matricula, String curso, double notas[]){
    this.nome = nome;
    this.matricula = matricula;
    this.curso = curso;
    this.notas = notas;
  }
}