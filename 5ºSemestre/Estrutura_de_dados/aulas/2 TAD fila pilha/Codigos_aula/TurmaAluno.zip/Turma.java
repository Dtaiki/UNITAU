public class Turma{
  String nome;
  Aluno alunos;
  int qtdAlunos;

  public Turma(String nome, int qtdAlunos){
    this.nome = nome;
    this.alunos = new Aluno[40];
    this.qtdAlunos = qtdAlunos;
  }

  public void adicionarAluno(Aluno aluno){
    if(this.qtdAlunos < 40){
      this.alunos[this.qtdAlunos] = aluno;
      this.qtdAlunos++;
    }
  }
  
}