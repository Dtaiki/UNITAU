public class Main{
    public static void main(String args[]){
        Lista l = new Lista();
        
        l.addInicio(11);
        l.addInicio(12);
        l.addInicio(13);
        l.addFim(1);
        l.addFim(2);
        l.addFim(3);
        l.addInicio(11);
        l.addInicio(12);
        l.addInicio(13);
        
        
        l.view();
        
        System.out.println("Valor removido: " + l.removeInicio());
        
        l.view();
        
        System.out.println("Aqui começa o codigo da Pilha");
        
        Pilha p = new Pilha();
        
        p.add(1);
        p.add(2);
        p.add(3);
        p.add(11);
        p.add(12);
        p.add(13);
        
        while(!p.isEmpty()){
            System.out.println(p.remove());
        }
    }
}
