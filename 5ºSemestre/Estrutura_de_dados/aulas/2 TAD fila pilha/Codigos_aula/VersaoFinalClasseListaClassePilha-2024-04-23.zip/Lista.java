
public class Lista{
    private Node inicio, fim;
    /**
     * Construtor para objetos da classe Lista
     */
    public Lista(){
        // inicializa variáveis de instância
        this.inicio = this.fim = null;
    }

    public void addFim(int x){
        if(this.inicio==null){
            this.inicio = new Node(x);
            this.fim = this.inicio;
        }
        else{
            this.fim.setProx(new Node(x));
            this.fim = this.fim.getProx();
        }
    }
    
    public void addInicio(int x){
        Node novo = new Node(x);
        if(this.inicio==null){
            this.inicio = this.fim = novo;
        }
        else{
            novo.setProx(inicio);
            inicio = novo;
        }
    }
    
    public int removeInicio(){
        Node atual = inicio;
        if(atual!=null){
            inicio = inicio.getProx();
            return atual.getX();
        }
        else{
            System.out.println("Erro: Tentativa de remoção em lista vazia");
            return -99999;
        }
    }
    
    public void view(){
        Node atual = inicio;
        while(atual!=null){
            System.out.println(atual.getX());
            atual = atual.getProx();
        }
        
    }
}
