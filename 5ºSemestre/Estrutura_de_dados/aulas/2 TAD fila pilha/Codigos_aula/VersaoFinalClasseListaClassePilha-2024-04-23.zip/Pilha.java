
public class Pilha{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    private Node topo;

    /**
     * Construtor para objetos da classe Pilha
     */
    public Pilha(){
        // inicializa variáveis de instância
        this.topo = null;
    }

    public void add(int x){
        Node novo = new Node(x);
        if(this.topo==null){
            this.topo = novo;
        }
        else{
            novo.setProx(topo);
            topo = novo;
        }
    }
    
    public int remove(){
        Node atual = topo;
        if(atual!=null){
            topo = topo.getProx();
            return atual.getX();
        }
        else{
            System.out.println("Erro: Tentativa de remoção em lista vazia");
            return -99999;
        }
    }
    
    public boolean isEmpty(){
        if(topo == null) return true;
        else return false;
    }
}
