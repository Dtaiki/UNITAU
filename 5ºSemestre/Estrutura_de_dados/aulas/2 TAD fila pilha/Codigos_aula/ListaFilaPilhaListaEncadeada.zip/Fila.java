public class Fila{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    private Node inicio, fim;

    /**
     * Construtor para objetos da classe Fila
     */
    public Fila(){
        // inicializa variáveis de instância
        inicio = fim = null;
    }

    public void push(int x){
        if(inicio==null){
            inicio = new Node(x);
            fim = inicio;
        }
        else{
            fim.setProx(new Node(x));
            fim = fim.getProx();
        }
    }
    
    public int pop(){
        Node aux = inicio;
        if(aux==null){
            System.out.println("Tentativa de remover em pilha vazia");
            return -99999;
        }
        else{
            inicio = inicio.getProx();
            if(inicio==null) fim=null;
            return aux.getX();
        }
    }
    
    public boolean isEmpty(){
        if(inicio==null) return true;
        else return false;
    }
}
