public class Principal{
    public static void main(String args[]){
        Lista l = new Lista();
        
        System.out.println(l);
        
        l.addFim(1);
        l.addFim(2);
        l.addFim(3);
        l.addFim(4);
    
        // l.addInicio(2);
        // l.addInicio(3);
        // l.addInicio(4);
        
        //l.show();
        l.misterio();
        l.show();
        
        // System.out.println("inicio removido: " + l.removeInicio());
        
        ///l.show();
        
        //l.qualquercoisa();
        
        // Exemplo prático - Pilha
        
        // Pilha p = new Pilha();
        
        // p.push(1);
        // p.push(2);
        // p.push(3);
        
        // while(!p.isEmpty()){
            // System.out.println(p.pop());
        // }
        
        // Fila f = new Fila();
    
        // f.push(1);
        // f.push(2);
        // f.push(3);
    
        // while(!f.isEmpty()){
            // System.out.println(f.pop());
        // }
    }
}
