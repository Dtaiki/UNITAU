public class Lista{
    // variáveis de instância
    private Node inicio, fim;

    public Lista(){
        inicio = fim = null;
    }

    public void addFim(int x){
        if(inicio==null){
            inicio = new Node(x);
            fim = inicio;
        }
        else{
            fim.setProx(new Node(x));
            fim = fim.getProx();
        }
    }
    
    public void addInicio(int x){
        if(inicio==null){
            inicio = new Node(x);
            fim = inicio;
        }
        else{
            Node novo = new Node(x);
            novo.setProx(inicio);
            inicio = novo;
        }
    }
    
    public int removeInicio(){
        Node aux = inicio;
        if(aux !=null ){
            inicio = inicio.getProx();
            return aux.getX();
        }
        else{
            System.out.println("Tentativa de remoção de lista vazia");
            return -99999;
        }
        
         
    }
    
    public void show(){
        Node aux = inicio;
        while(aux!=null){
            System.out.println(aux.getX());
            aux = aux.getProx();
        }
    }
    
    public void qualquercoisa(){
        System.out.println(inicio);
        System.out.println(inicio.getProx());
        System.out.println(fim);
    }
    
    public void misterio(){
        Node aux1 = null;
        Node aux2 = inicio;
        fim = inicio;
        
        while(aux2 != null){
            inicio = aux2.getProx();
            aux2.setProx(aux1);
            aux1 = aux2;
            aux2 = inicio;
        }
        
        inicio = aux1;
    }
}





