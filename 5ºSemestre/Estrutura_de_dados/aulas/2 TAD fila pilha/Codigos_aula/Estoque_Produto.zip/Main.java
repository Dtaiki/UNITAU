public class Main {
  public static void main(String[] args) {
    Produto p = new Produto("camisa", 1, 3, 50);
    Estoque e = new Estoque(10);

    e.adicionar(p);
    e.adicionar(p);
    e.adicionar(p);

    e.remover(1);
    
    System.out.println(e.quantidade);
    
    
  }

}