public class Produto{
  String nome;
  int codigo;
  int quantidade;
  double preco;

  public Produto(String nome, int codigo, int quantidade, double preco){
    this.nome = nome;
    this.codigo = codigo;
    this.quantidade = quantidade;
    this.preco = preco;
  }
}