public class Estoque{
  Produto produtos[];
  int quantidade;

  public Estoque(int n){
    produtos = new Produto[n];
    quantidade = 0;
  }

  public void adicionar(Produto p){
    if(quantidade < produtos.length){
      produtos[quantidade] = p;
      quantidade++;
    }
    else{
      System.out.println("Estoque cheio!");
    }
  }

  public void remover(int codigo){
    for(int i = 0; i < quantidade; i++){
      if(produtos[i].codigo == codigo){
        for(int j = i; j < quantidade-1; j++){
          produtos[j] = produtos[j+1];
        }
        quantidade--;
        break;
      }
    }
  }

  public void atualizaQuantidade(int codigo, int quantidade){
    for(int i = 0; i < quantidade; i++){
      if(produtos[i].codigo == codigo){
        produtos[i].quantidade = quantidade;
        break;
      }
    }
  }
   
}