public class Main{
    public static void main(String args[]){
        // Node inicio = new Node(1);
        
        // System.out.println(inicio);
        // System.out.println(inicio.x);
        
        // Node novo = new Node(2);
        
        // inicio.prox = novo;
        
        // System.out.println(inicio.prox.x);
        
        // inicio.prox.prox = new Node(3);
        
        // System.out.println(inicio.prox.prox.x);
        
        // Segunda versão
        
        Node inicio = new Node(1);
        Node novo = new Node(2);
        inicio.setProx(novo);
        inicio.getProx().setProx(new Node(3));
        
        System.out.println(inicio.getX());
        System.out.println(inicio.getProx().getX());
        System.out.println(inicio.getProx().getProx().getX());
    }
}
